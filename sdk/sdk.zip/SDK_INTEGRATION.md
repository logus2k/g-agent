# Voice Agent SDK Integration Guide

## Overview

This SDK provides a complete solution for building voice-enabled conversational AI applications. It integrates three core services:
- **STT (Speech-to-Text)**: Real-time audio transcription
- **LLM (Large Language Model)**: Conversational AI agent
- **TTS (Text-to-Speech)**: Audio synthesis from text

## Architecture

```
┌─────────────┐
│   Browser   │
│   Client    │
└──────┬──────┘
       │
       ├─────────────────┐
       │                 │
       ▼                 ▼
┌─────────────┐   ┌─────────────┐
│ STT Server  │   │ Agent Server│
│ (Direct)    │   │  (LLM Proxy)│
└─────────────┘   └──────┬──────┘
                         │
                         ├─────────────┐
                         │             │
                         ▼             ▼
                  ┌─────────────┐ ┌─────────────┐
                  │ LLM Service │ │ TTS Server  │
                  └─────────────┘ └─────────────┘
```

### Key Components

1. **AgentClient**: Main SDK class for LLM communication and coordination
2. **AudioResampler**: Converts browser audio (48kHz) to STT format (16kHz)
3. **Direct STT Socket**: WebSocket connection for audio streaming
4. **Direct TTS Socket**: WebSocket connection for audio playback

## Quick Start

### 1. Include Required Dependencies

```html
<!-- Socket.IO Client -->
<script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>

<!-- SDK Files -->
<script type="module">
  import { AgentClient } from './sdk/agentClient.js';
  import { AudioResampler } from './sdk/audioResampler.js';
  import { initLLM } from './sdk/llm-bridge.js';
  
  // Your app code here
</script>
```

### 2. Initialize the SDK

```javascript
import { initLLM } from './sdk/llm-bridge.js';

const { client, send, cancel, getThreadId, setThreadId } = await initLLM({
  url: 'https://your-llm-server.com',
  agent: 'your-agent-name',
  clientId: 'unique-client-id',
  onStarted: (runId) => {
    console.log('LLM started:', runId);
  },
  onText: (text) => {
    console.log('Streaming text:', text);
  },
  onDone: () => {
    console.log('LLM complete');
  },
  onError: (err) => {
    console.error('LLM error:', err);
  }
});
```

### 3. Send Text Messages

```javascript
// Send a message to the LLM
await send("Hello, how are you?");

// Cancel an ongoing response
cancel();
```

### 4. Enable Speech-to-Text

```javascript
// Connect to STT server
const sttOrigin = new URL('https://your-stt-server.com').origin;
const sttSocket = io(sttOrigin, {
  path: '/stt/socket.io',
  transports: ['websocket', 'polling']
});

await new Promise((resolve, reject) => {
  sttSocket.once('connect', resolve);
  sttSocket.once('connect_error', reject);
});

// Subscribe to transcripts via agent server
await client.sttSubscribe({
  sttUrl: 'https://your-stt-server.com',
  clientId: 'unique-client-id',
  agent: 'your-agent-name',
  threadId: getThreadId()
});

// Handle transcripts
client.onTranscripts({
  onInterim: (transcript) => {
    console.log('Interim:', transcript.text);
  },
  onFinal: (transcript) => {
    console.log('Final:', transcript.text);
    // Auto-send to LLM
    send(transcript.text);
  }
});

// Setup audio recording
const mediaStream = await navigator.mediaDevices.getUserMedia({
  audio: {
    channelCount: 1,
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: false
  }
});

const audioCtx = new AudioContext({ sampleRate: 48000 });
await audioCtx.audioWorklet.addModule('./sdk/recorder.worklet.js');

const sourceNode = audioCtx.createMediaStreamSource(mediaStream);
const workletNode = new AudioWorkletNode(audioCtx, 'recorder-worklet');
sourceNode.connect(workletNode);

// Setup resampler (48kHz -> 16kHz)
const resampler = new AudioResampler(48000, 16000);

// Stream audio to STT
workletNode.port.onmessage = (e) => {
  const pcm16 = resampler.pushFloat32(e.data);
  if (pcm16?.length > 0) {
    sttSocket.emit('audio_data', {
      clientId: 'unique-client-id',
      audioData: pcm16.buffer
    });
  }
};
```

### 5. Enable Text-to-Speech

```javascript
// Subscribe via agent server
await client.ttsSubscribe({
  clientId: 'unique-client-id',
  voice: 'default',
  speed: 1.0
});

// Connect to TTS server
const ttsOrigin = new URL('https://your-tts-server.com').origin;
const ttsSocket = io(ttsOrigin, {
  path: '/tts/socket.io',
  transports: ['websocket', 'polling'],
  query: {
    type: 'browser',
    format: 'binary',
    main_client_id: 'unique-client-id'
  }
});

await new Promise((resolve, reject) => {
  ttsSocket.once('connect', resolve);
  ttsSocket.once('connect_error', reject);
});

// Register as audio client
await new Promise((resolve) => {
  ttsSocket.emit('register_audio_client', {
    main_client_id: 'unique-client-id',
    connection_type: 'browser',
    mode: 'tts'
  }, resolve);
});

// Setup audio playback
let ttsAudioCtx = null;
let ttsPlayQueue = Promise.resolve();

const ensureTtsAudioContext = () => {
  if (!ttsAudioCtx) {
    ttsAudioCtx = new AudioContext();
  }
  return ttsAudioCtx;
};

// Handle incoming audio
ttsSocket.on('tts_audio_chunk', async (evt) => {
  const buf = evt?.audio_buffer;
  if (!buf) return;
  
  const actx = ensureTtsAudioContext();
  try {
    const audioBuf = await actx.decodeAudioData(buf.slice(0));
    ttsPlayQueue = ttsPlayQueue.then(() => {
      const src = actx.createBufferSource();
      src.buffer = audioBuf;
      src.connect(actx.destination);
      src.start();
      return new Promise(res => { src.onended = res; });
    });
  } catch (e) {
    console.warn('TTS decode error:', e);
  }
});

// Handle stop/interruption
ttsSocket.on('tts_stop_immediate', () => {
  if (ttsAudioCtx) {
    ttsAudioCtx.close();
    ttsAudioCtx = null;
  }
  ttsPlayQueue = Promise.resolve();
});
```

## API Reference

### AgentClient

#### Constructor
```javascript
new AgentClient({ url?: string, path?: string })
```

#### Methods

**connect(options?)**
```javascript
await client.connect({
  onReconnect: (attempt) => console.log('Reconnected after', attempt, 'attempts')
});
```

**disconnect()**
```javascript
client.disconnect();
```

**runText(text, options, callbacks?)**
```javascript
const result = await client.runText(
  "Your message",
  { 
    agent: "agent-name",
    threadId: "thread-id",
    memory: "thread_window"
  },
  {
    onStarted: (runId) => {},
    onChunk: (piece) => {},
    onText: (fullText) => {},
    onDone: () => {},
    onError: (err) => {}
  }
);
```

**cancel()**
```javascript
client.cancel();
```

**onStream(callbacks)**
```javascript
client.onStream({
  onStarted: (runId) => {},
  onChunk: (piece) => {},
  onText: (fullText) => {},
  onDone: () => {},
  onError: (err) => {}
});
```

**onTranscripts(callbacks)**
```javascript
client.onTranscripts({
  onInterim: (transcript) => {
    // { text, final: false, uttId?, threadId?, clientId?, ts?, lang?, duration? }
  },
  onFinal: (transcript) => {
    // { text, final: true, uttId?, threadId?, clientId?, ts?, lang?, duration? }
  }
});
```

**sttSubscribe(args)**
```javascript
await client.sttSubscribe({
  sttUrl: 'https://stt-server.com',
  clientId: 'client-id',
  agent: 'agent-name',
  threadId: 'thread-id'
});
```

**sttUnsubscribe(args)**
```javascript
await client.sttUnsubscribe({
  sttUrl: 'https://stt-server.com',
  clientId: 'client-id'
});
```

**ttsSubscribe(args)**
```javascript
await client.ttsSubscribe({
  clientId: 'client-id',
  voice: 'default',
  speed: 1.0
});
```

**ttsUnsubscribe(args)**
```javascript
await client.ttsUnsubscribe({
  clientId: 'client-id'
});
```

### AudioResampler

#### Constructor
```javascript
const resampler = new AudioResampler(inputRate, outputRate);
// Example: new AudioResampler(48000, 16000)
```

#### Methods

**pushFloat32(chunk)**
```javascript
const pcm16 = resampler.pushFloat32(float32Array);
// Returns Int16Array or null if not enough data yet
```

**reset()**
```javascript
resampler.reset();
```

### initLLM Helper

```javascript
const { client, send, cancel, getThreadId, setThreadId } = await initLLM({
  url: 'https://llm-server.com',
  agent: 'agent-name',
  clientId: 'client-id',
  onStarted: (runId) => {},
  onText: (text) => {},
  onDone: () => {},
  onError: (err) => {},
  onReconnect: (attempt) => {}
});
```

## Event Reference

### STT Events

**UserTranscript** (from Agent Server)
```javascript
{
  text: string,
  final: boolean,
  uttId?: string,
  threadId?: string,
  clientId?: string,
  ts?: number,
  lang?: string,
  duration?: number
}
```

### LLM Events

**RunStarted**
```javascript
{ runId: string }
```

**ChatChunk**
```javascript
{ chunk: string }
```

**ChatDone**
```javascript
{}
```

**Interrupted**
```javascript
{}
```

**Error**
```javascript
{
  code: string,
  message: string,
  runId?: string
}
```

### TTS Events

**tts_audio_chunk**
```javascript
{
  audio_buffer: ArrayBuffer
}
```

**tts_stop_immediate**
```javascript
{}
```

## Best Practices

### 1. Client ID Management
```javascript
// Generate unique client ID per session
const clientId = crypto.randomUUID?.() || 
                 Math.random().toString(36).slice(2);
```

### 2. Thread ID Management
```javascript
// Use thread ID for conversation continuity
const threadId = getThreadId();
// Or create new thread
setThreadId(crypto.randomUUID());
```

### 3. Error Handling
```javascript
try {
  await client.connect();
} catch (err) {
  console.error('Connection failed:', err);
  // Implement retry logic
}
```

### 4. Memory Management
```javascript
// Clean up when done
client.disconnect();
mediaStream?.getTracks().forEach(t => t.stop());
audioCtx?.close();
ttsAudioCtx?.close();
```

### 5. Interruption Handling
```javascript
// When user interrupts (e.g., starts speaking):
cancel(); // Cancel LLM response

// TTS will automatically stop via tts_stop_immediate event
```

### 6. Audio Context State
```javascript
// Resume audio context on user interaction (required by browsers)
document.addEventListener('click', () => {
  if (audioCtx?.state === 'suspended') {
    audioCtx.resume();
  }
}, { once: true });
```

## Common Patterns

### Full Voice Conversation Loop

```javascript
let isRecording = false;

// Start recording
async function startRecording() {
  if (isRecording) return;
  isRecording = true;
  
  // Audio setup...
  workletNode.port.onmessage = (e) => {
    const pcm16 = resampler.pushFloat32(e.data);
    if (pcm16) {
      sttSocket.emit('audio_data', { clientId, audioData: pcm16.buffer });
    }
  };
}

// Stop recording
function stopRecording() {
  isRecording = false;
  sourceNode?.disconnect();
  workletNode?.disconnect();
  mediaStream?.getTracks().forEach(t => t.stop());
}

// Handle final transcripts
client.onTranscripts({
  onFinal: async (transcript) => {
    stopRecording();
    await send(transcript.text);
  }
});
```

### Push-to-Talk

```javascript
button.addEventListener('mousedown', startRecording);
button.addEventListener('mouseup', stopRecording);
```

### Voice Activation Detection (VAD)

```javascript
// Implement custom VAD or use library
const vad = new VoiceActivityDetector();

vad.on('speechStart', startRecording);
vad.on('speechEnd', stopRecording);
```

## Troubleshooting

### No Audio Playback

1. Check audio context state:
```javascript
console.log(ttsAudioCtx.state); // Should be 'running'
```

2. Resume on user interaction:
```javascript
ttsAudioCtx.resume();
```

3. Verify TTS subscription:
```javascript
await client.ttsSubscribe({ clientId });
```

### Audio Cuts Out After Interruption

Ensure audio context is NOT closed on interruption:
```javascript
ttsSocket.on('tts_stop_immediate', () => {
  // Close context to stop audio
  ttsAudioCtx?.close();
  ttsAudioCtx = null;
  // New context will be created automatically
});
```

### Transcripts Not Arriving

1. Verify STT subscription:
```javascript
await client.sttSubscribe({ sttUrl, clientId, agent, threadId });
```

2. Check audio format:
```javascript
// Must be 16kHz, mono, Int16 PCM
const resampler = new AudioResampler(48000, 16000);
```

3. Verify audio data emission:
```javascript
sttSocket.emit('audio_data', {
  clientId: 'your-client-id',
  audioData: pcm16.buffer // ArrayBuffer, not Int16Array
});
```

### LLM Connection Issues

1. Check socket connection:
```javascript
console.log(client.socket?.connected);
```

2. Verify agent name and thread ID:
```javascript
await client.runText(text, { 
  agent: 'correct-agent-name',
  threadId: getThreadId()
});
```

## Examples

See the included example files:
- `example-minimal.html` - Minimal text-only chat
- `example-voice.html` - Full voice-enabled assistant
- `example-ptt.html` - Push-to-talk implementation

## Support

For issues or questions:
- Check server logs for connection/subscription errors
- Enable debug logging: `localStorage.debug = '*'`
- Review browser console for client-side errors

## License

[Your License Here]
