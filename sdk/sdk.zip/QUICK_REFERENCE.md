# Voice Agent SDK - Quick Reference

## Installation

```html
<script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
<script type="module">
  import { initLLM } from './sdk/llm-bridge.js';
  import { AudioResampler } from './sdk/audioResampler.js';
</script>
```

## Initialize LLM

```javascript
const { client, send, cancel, getThreadId, setThreadId } = await initLLM({
  url: 'https://your-server.com',
  agent: 'agent-name',
  clientId: crypto.randomUUID(),
  onStarted: (runId) => {},
  onText: (text) => {},
  onDone: () => {},
  onError: (err) => {}
});
```

## Send Message

```javascript
await send("Your message");
```

## Cancel Response

```javascript
cancel();
```

## STT Setup

```javascript
// 1. Connect to STT
const sttSocket = io('https://stt-server.com', {
  path: '/stt/socket.io',
  transports: ['websocket', 'polling']
});

// 2. Subscribe via agent
await client.sttSubscribe({
  sttUrl: 'https://stt-server.com',
  clientId: 'your-client-id',
  agent: 'agent-name',
  threadId: getThreadId()
});

// 3. Handle transcripts
client.onTranscripts({
  onInterim: (t) => console.log('Interim:', t.text),
  onFinal: (t) => send(t.text)
});

// 4. Setup audio
const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
const audioCtx = new AudioContext({ sampleRate: 48000 });
await audioCtx.audioWorklet.addModule('./sdk/recorder.worklet.js');

const source = audioCtx.createMediaStreamSource(stream);
const worklet = new AudioWorkletNode(audioCtx, 'recorder-worklet');
source.connect(worklet);

// 5. Resample and stream
const resampler = new AudioResampler(48000, 16000);
worklet.port.onmessage = (e) => {
  const pcm16 = resampler.pushFloat32(e.data);
  if (pcm16) {
    sttSocket.emit('audio_data', {
      clientId: 'your-client-id',
      audioData: pcm16.buffer
    });
  }
};
```

## TTS Setup

```javascript
// 1. Subscribe via agent
await client.ttsSubscribe({
  clientId: 'your-client-id',
  voice: 'default',
  speed: 1.0
});

// 2. Connect to TTS
const ttsSocket = io('https://tts-server.com', {
  path: '/tts/socket.io',
  query: {
    type: 'browser',
    format: 'binary',
    main_client_id: 'your-client-id'
  }
});

// 3. Register
await new Promise((resolve) => {
  ttsSocket.emit('register_audio_client', {
    main_client_id: 'your-client-id',
    connection_type: 'browser',
    mode: 'tts'
  }, resolve);
});

// 4. Handle audio
let ttsAudioCtx = null;
let ttsPlayQueue = Promise.resolve();

ttsSocket.on('tts_audio_chunk', async (evt) => {
  if (!ttsAudioCtx) ttsAudioCtx = new AudioContext();
  
  const audioBuf = await ttsAudioCtx.decodeAudioData(evt.audio_buffer.slice(0));
  ttsPlayQueue = ttsPlayQueue.then(() => {
    const src = ttsAudioCtx.createBufferSource();
    src.buffer = audioBuf;
    src.connect(ttsAudioCtx.destination);
    src.start();
    return new Promise(res => { src.onended = res; });
  });
});

// 5. Handle stop
ttsSocket.on('tts_stop_immediate', () => {
  if (ttsAudioCtx) {
    ttsAudioCtx.close();
    ttsAudioCtx = null;
  }
  ttsPlayQueue = Promise.resolve();
});
```

## Common Patterns

### Push to Talk

```javascript
button.addEventListener('mousedown', startRecording);
button.addEventListener('mouseup', stopRecording);
```

### Clean Shutdown

```javascript
// STT
sourceNode?.disconnect();
workletNode?.disconnect();
stream?.getTracks().forEach(t => t.stop());
audioCtx?.close();
sttSocket?.disconnect();

// TTS
await client.ttsUnsubscribe({ clientId });
ttsSocket?.disconnect();
ttsAudioCtx?.close();

// LLM
client.disconnect();
```

### Error Handling

```javascript
try {
  await send(text);
} catch (err) {
  if (err.code === 'INTERRUPTED') {
    // User interrupted
  } else {
    console.error('Error:', err.message);
  }
}
```

## Key Points

- ✅ Generate unique `clientId` per session
- ✅ Use `threadId` for conversation continuity
- ✅ Audio must be 16kHz mono Int16 PCM for STT
- ✅ Resume AudioContext on user interaction
- ✅ Close AudioContext on `tts_stop_immediate` to stop audio
- ✅ Always clean up resources when done

## Service Endpoints

| Service | Default Path       | Purpose                    |
|---------|-------------------|----------------------------|
| LLM     | /llm/socket.io    | Chat streaming             |
| STT     | /stt/socket.io    | Speech transcription       |
| TTS     | /tts/socket.io    | Audio synthesis            |

## Events

### From Client

- `Chat` - Send message to LLM
- `Interrupt` - Cancel current response
- `JoinSTT` - Subscribe to transcripts
- `LeaveSTT` - Unsubscribe from transcripts
- `JoinTTS` - Enable TTS
- `LeaveTTS` - Disable TTS
- `audio_data` - Send audio to STT (direct)
- `register_audio_client` - Register for TTS (direct)

### From Server

- `RunStarted` - LLM response starting
- `ChatChunk` - LLM text chunk
- `ChatDone` - LLM response complete
- `Interrupted` - Response cancelled
- `Error` - Error occurred
- `UserTranscript` - STT transcript (via agent)
- `tts_audio_chunk` - TTS audio (direct)
- `tts_stop_immediate` - Stop TTS (direct)
