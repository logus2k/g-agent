# Voice Agent SDK

A lightweight JavaScript SDK for building voice-enabled conversational AI applications. Integrates Speech-to-Text (STT), Large Language Model (LLM), and Text-to-Speech (TTS) services.

## Features

- 🎤 Real-time speech recognition
- 💬 Streaming LLM responses
- 🔊 Text-to-speech audio playback
- 🔄 Automatic reconnection handling
- 🎯 Low-latency audio processing
- 🌐 Browser-based (no backend required)

## Quick Start

### 1. Installation

Include Socket.IO and the SDK:

```html
<script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
<script type="module">
  import { initLLM } from './sdk/llm-bridge.js';
  // Your code here
</script>
```

### 2. Basic Text Chat

```javascript
import { initLLM } from './sdk/llm-bridge.js';

const { send } = await initLLM({
  url: 'https://your-server.com',
  agent: 'your-agent',
  clientId: crypto.randomUUID(),
  onText: (text) => console.log(text),
  onDone: () => console.log('Complete')
});

await send("Hello!");
```

### 3. Add Voice Input

```javascript
import { AudioResampler } from './sdk/audioResampler.js';

// Setup microphone
const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
const audioCtx = new AudioContext({ sampleRate: 48000 });
await audioCtx.audioWorklet.addModule('./sdk/recorder.worklet.js');

const source = audioCtx.createMediaStreamSource(stream);
const worklet = new AudioWorkletNode(audioCtx, 'recorder-worklet');
source.connect(worklet);

// Setup resampler
const resampler = new AudioResampler(48000, 16000);

// Stream to STT
worklet.port.onmessage = (e) => {
  const pcm16 = resampler.pushFloat32(e.data);
  if (pcm16) {
    sttSocket.emit('audio_data', {
      clientId: 'your-client-id',
      audioData: pcm16.buffer
    });
  }
};
```

## Documentation

See [SDK_INTEGRATION.md](SDK_INTEGRATION.md) for complete documentation.

## Examples

- `example-minimal.html` - Basic text chat
- `example-voice.html` - Full voice assistant with push-to-talk

## File Structure

```
sdk/
├── agentClient.js       - Main SDK client
├── audioResampler.js    - Audio processing
├── llm-bridge.js        - High-level LLM wrapper
└── recorder.worklet.js  - Audio worklet processor
```

## Configuration

### Service URLs

Configure your service endpoints:

```javascript
const config = {
  llmUrl: 'https://your-llm-server.com',
  sttUrl: 'https://your-stt-server.com',
  agent: 'your-agent-name',
  clientId: crypto.randomUUID()
};
```

### Socket.IO Paths

Default paths:
- LLM: `/llm/socket.io`
- STT: `/stt/socket.io`
- TTS: `/tts/socket.io`

## Browser Support

- Chrome/Edge 89+
- Firefox 88+
- Safari 14.1+

Requires:
- WebAudio API
- AudioWorklet
- getUserMedia
- WebSocket

## Best Practices

1. **Generate unique client IDs** per session
2. **Use thread IDs** for conversation continuity
3. **Handle reconnections** gracefully
4. **Clean up resources** when done
5. **Resume AudioContext** on user interaction

## Troubleshooting

### No audio playback?
```javascript
// Resume on user interaction
document.addEventListener('click', () => {
  audioContext.resume();
}, { once: true });
```

### Transcripts not arriving?
- Verify STT subscription with correct clientId
- Check audio format (16kHz mono PCM)
- Ensure audio data is ArrayBuffer

### Connection issues?
- Check CORS settings
- Verify WebSocket support
- Enable debug logging: `localStorage.debug = '*'`

## License

MIT

## Support

For issues or questions, please check the integration guide or contact support.
